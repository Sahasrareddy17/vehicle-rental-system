# Roadly — Vehicle Rental System

A responsive front-end prototype for a vehicle rental system. The first/main file is `index.html`; it contains the HTML, CSS, and JavaScript in one file, so it can be opened directly in a browser or deployed with GitHub Pages.

## Features
- Responsive landing page and vehicle cards
- Filter by SUV, Sedan, Hatchback, and Electric
- Search by pickup location, dates, and vehicle type
- Booking request modal with date validation and estimated rental total
- Software design-pattern notes included on the website

## Design patterns proposed
1. **Factory Method / Simple Factory** — create vehicle objects by type.
2. **Strategy** — swap pricing algorithms (vehicle class, duration discounts, seasonal rates).
3. **Observer** — notify customers and update availability/admin views when booking status changes.
4. **Singleton (limited use)** — shared application configuration or a connection manager per process.
5. **State** — control valid booking transitions such as Pending → Confirmed → Active → Completed / Cancelled.
6. **Repository** — isolate persistence queries behind `VehicleRepository` and `BookingRepository`.

These are documented in the prototype; the current demo is front-end only. Real reservations, availability, authentication, and payments require a backend and server-side validation.

## Run locally
Open `index.html` in a browser. No build step is required.

## Push to GitHub
1. Create a new empty repository on https://github.com/new (for example, `vehicle-rental-system`).
2. Download `index.html` and `README.md` into one folder.
3. Open a terminal in that folder and run:

```bash
git init
git add index.html README.md
git commit -m "Build Roadly vehicle rental prototype"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/vehicle-rental-system.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. If you use GitHub Desktop, create a repository from the folder, commit the files, and select **Publish repository**.

## Optional: publish using GitHub Pages
In the repository, open **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save. Wait for the Pages URL to appear.
